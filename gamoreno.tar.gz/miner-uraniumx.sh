#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a yespowerURX -o stratum+tcp://stratum.rplant.xyz:3361 -u WALLET.WORKER_NAME
done
